package com.emeboy04.potionskill;

import net.kyori.adventure.text.Component;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.potion.PotionEffect;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SkillListener implements Listener {

    private final PotionSkillPlugin plugin;
    private final SkillManager manager;
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    public SkillListener(PotionSkillPlugin plugin, SkillManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getConfig().getBoolean("assign-on-join", true)) return;

        if (!manager.hasSkill(player.getUniqueId())) {
            Skill skill = manager.assignRandom(player.getUniqueId());
            if (skill != null) {
                player.sendMessage(plugin.msg("assigned")
                        .replaceText(b -> b.matchLiteral("%skill%")
                                .replacement(PotionSkillPlugin.color(skill.displayName()))));
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        cooldowns.remove(event.getPlayer().getUniqueId());
    }

    /** Tombol F = swap item ke offhand. Kalau sambil Shift, kita pakai sebagai skill. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSwap(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();

        if (plugin.getConfig().getBoolean("require-sneak", true) && !player.isSneaking()) {
            return; // F biasa tetap berfungsi normal (tukar item)
        }

        event.setCancelled(true); // cegah item tertukar ke offhand

        if (!player.hasPermission("potionskill.use")) {
            player.sendMessage(plugin.msg("no-permission"));
            return;
        }

        Skill skill = manager.getPlayerSkill(player.getUniqueId());
        if (skill == null) {
            player.sendMessage(plugin.msg("no-skill"));
            return;
        }

        long now = System.currentTimeMillis();
        long cooldownMs = plugin.getConfig().getLong("cooldown-seconds", 30) * 1000L;
        long readyAt = cooldowns.getOrDefault(player.getUniqueId(), 0L);

        if (now < readyAt) {
            double left = Math.ceil((readyAt - now) / 100.0) / 10.0;
            Component m = plugin.msg("cooldown")
                    .replaceText(b -> b.matchLiteral("%time%").replacement(String.valueOf(left)));
            player.sendActionBar(m);
            return;
        }

        for (PotionEffect effect : skill.effects()) {
            player.addPotionEffect(effect);
        }
        cooldowns.put(player.getUniqueId(), now + cooldownMs);

        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);
        player.sendActionBar(plugin.msg("used")
                .replaceText(b -> b.matchLiteral("%skill%").replacement(PotionSkillPlugin.color(skill.displayName()))));
    }
}
