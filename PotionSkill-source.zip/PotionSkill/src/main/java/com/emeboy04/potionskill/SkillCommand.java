package com.emeboy04.potionskill;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SkillCommand implements CommandExecutor, TabCompleter {

    private final PotionSkillPlugin plugin;
    private final SkillManager manager;

    public SkillCommand(PotionSkillPlugin plugin, SkillManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    private void say(CommandSender to, String text) {
        to.sendMessage(PotionSkillPlugin.color(text));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub = args.length == 0 ? "info" : args[0].toLowerCase(Locale.ROOT);

        switch (sub) {
            case "info" -> {
                if (!(sender instanceof Player p)) {
                    say(sender, "&cHanya untuk player.");
                    return true;
                }
                Skill s = manager.getPlayerSkill(p.getUniqueId());
                if (s == null) {
                    p.sendMessage(plugin.msg("no-skill"));
                    return true;
                }
                say(p, "&8&m      &r &aSkill kamu &8&m      ");
                say(p, "&7Nama: " + s.displayName());
                for (PotionEffect e : s.effects()) {
                    say(p, "&8- &f" + e.getType().getKey().getKey()
                            + " &7level &e" + (e.getAmplifier() + 1)
                            + " &7(" + (e.getDuration() / 20) + " detik)");
                }
                say(p, "&7Tekan &eShift + F &7untuk memakai.");
            }

            case "list" -> {
                say(sender, "&aDaftar skill:");
                manager.getSkills().values().forEach(s ->
                        say(sender, "&8- &f" + s.id() + " &7= " + s.displayName()));
            }

            case "set" -> {
                if (!admin(sender)) return true;
                if (args.length < 3) {
                    say(sender, "&cGunakan: /pskill set <player> <skill>");
                    return true;
                }
                Player target = Bukkit.getPlayer(args[1]);
                Skill skill = manager.getSkill(args[2]);
                if (target == null) {
                    say(sender, "&cPlayer tidak ditemukan / offline.");
                    return true;
                }
                if (skill == null) {
                    say(sender, "&cSkill tidak ada. Cek /pskill list");
                    return true;
                }
                manager.setSkill(target.getUniqueId(), skill);
                say(sender, "&a" + target.getName() + " sekarang punya skill " + skill.displayName());
                say(target, "&7Skill kamu diubah menjadi " + skill.displayName());
            }

            case "reroll" -> {
                if (!admin(sender)) return true;
                Player target;
                if (args.length >= 2) {
                    target = Bukkit.getPlayer(args[1]);
                } else if (sender instanceof Player p) {
                    target = p;
                } else {
                    say(sender, "&cGunakan: /pskill reroll <player>");
                    return true;
                }
                if (target == null) {
                    say(sender, "&cPlayer tidak ditemukan / offline.");
                    return true;
                }
                Skill s = manager.assignRandom(target.getUniqueId());
                if (s == null) {
                    say(sender, "&cTidak ada skill di config.");
                    return true;
                }
                say(sender, "&a" + target.getName() + " mendapat skill " + s.displayName());
                say(target, "&7Skill baru kamu: " + s.displayName());
            }

            case "reload" -> {
                if (!admin(sender)) return true;
                manager.load();
                say(sender, "&aConfig dimuat ulang. " + manager.getSkills().size() + " skill.");
            }

            default -> say(sender, "&cGunakan: /pskill <info|list|set|reroll|reload>");
        }
        return true;
    }

    private boolean admin(CommandSender sender) {
        if (sender.hasPermission("potionskill.admin")) return true;
        sender.sendMessage(plugin.msg("no-permission"));
        return false;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            out.addAll(List.of("info", "list"));
            if (sender.hasPermission("potionskill.admin")) out.addAll(List.of("set", "reroll", "reload"));
        } else if (args.length == 2 && sender.hasPermission("potionskill.admin")
                && (args[0].equalsIgnoreCase("set") || args[0].equalsIgnoreCase("reroll"))) {
            Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        } else if (args.length == 3 && args[0].equalsIgnoreCase("set")
                && sender.hasPermission("potionskill.admin")) {
            out.addAll(manager.getSkills().keySet());
        }
        String last = args[args.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
