package com.emeboy04.potionskill;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class PotionSkillPlugin extends JavaPlugin {

    private SkillManager skillManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        skillManager = new SkillManager(this);
        skillManager.load();

        getServer().getPluginManager().registerEvents(new SkillListener(this, skillManager), this);

        PluginCommand cmd = getCommand("pskill");
        if (cmd != null) {
            SkillCommand executor = new SkillCommand(this, skillManager);
            cmd.setExecutor(executor);
            cmd.setTabCompleter(executor);
        }

        getLogger().info("PotionSkill aktif! " + skillManager.getSkills().size() + " skill dimuat.");
    }

    @Override
    public void onDisable() {
        if (skillManager != null) {
            skillManager.save();
        }
    }

    /** Ubah teks berkode warna & (mis. &a) jadi Component. */
    public static Component color(String text) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(text);
    }

    /** Ambil pesan dari config (dengan prefix). */
    public Component msg(String key) {
        String prefix = getConfig().getString("messages.prefix", "");
        return color(prefix + getConfig().getString("messages." + key, key));
    }
}
